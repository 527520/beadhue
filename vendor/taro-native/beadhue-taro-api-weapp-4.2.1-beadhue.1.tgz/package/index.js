if (process.env.TARO_ENV !== 'weapp') {
  throw new Error('BeadHue native Taro API package supports only weapp; H5 is not included.');
}

const { hooks } = require('@tarojs/runtime')
const taro = require('@tarojs/api').default

if (hooks.isExist('initNativeApi')) {
  hooks.call('initNativeApi', taro)
}

module.exports = taro
module.exports.default = module.exports
